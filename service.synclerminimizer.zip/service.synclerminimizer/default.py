import xbmc

class Monitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        xbmc.log("Kodi Minimizer Timer Service started", level=xbmc.LOGINFO)

    def onPlaybackStarted(self):
        xbmc.log("Playback started, beginning timer", level=xbmc.LOGINFO)
        self.wait_for_playback_end()

    def wait_for_playback_end(self):
        while xbmc.Player().isPlayingVideo():
            xbmc.sleep(1000)
        xbmc.log("Playback ended by timer - minimizing Kodi", level=xbmc.LOGINFO)
        xbmc.executebuiltin('Minimize')

monitor = Monitor()
player = xbmc.Player()

while not monitor.abortRequested():
    if player.isPlayingVideo():
        monitor.onPlaybackStarted()
    xbmc.sleep(1000)